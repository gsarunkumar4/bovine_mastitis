from pathlib import Path
from datetime import datetime, timezone
import json, joblib, pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from config import (
    ROOT, MODELS_DIR, FEATURE_PIPELINE_VERSION,
    DATA_TYPE, USE_REAL_FARM_FEATURES, FIXED_GOOD_VALUES,
    TIER_THRESHOLDS,
)
from app.services.database import init_db, connect
from app.services.features import (
    validate_reading, engineer, aggregate_daily,
    derive_heat_index,
)
from app.services.explainability import top_drivers
from app.services.recommendations import recommendations
from app.services.versioning import has_current_model, load_current_model, list_versions
from app.services.calibration import apply_calibration
from app.services.data_quality import (
    check_reading_quality, check_timestamp_sanity,
    check_scc_staleness, check_abnormal_jump,
)
from app.services.drift import summarize_drift
from app.routes.cows import router as cows_router

app = FastAPI(title="MastiSense Daily 7/14-Day Mastitis Risk Forecasting API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(cows_router)

models = {}
calibrators = {}
feature_cols = []
metrics = {}
active_version = None
metadata = {}


class Reading(BaseModel):
    cow_id: str
    timestamp: str | None = None
    # Core daily sensor values.
    milk_yield_l: float = Field(ge=0)
    milk_conductivity: float = Field(gt=0)
    milk_temp_c: float
    # SCC is supplied periodically (cow-side test / lab).
    scc_value: float | None = Field(default=None, ge=0)
    source: str = "sensor"
    # Optional farm/behaviour inputs (prototype fixed baselines if omitted).
    activity_score: float | None = None
    rumination_min: float | None = None
    environment_heat_index: float | None = None
    hygiene_score: float | None = None
    feed_score: float | None = None
    milking_hygiene_score: float | None = None
    # Extended sensor inputs (supported by latest ESP32 / future hardware).
    farm_temperature_c: float | None = None
    farm_humidity: float | None = None
    milk_pH: float | None = None
    body_temperature: float | None = None
    udder_surface_temperature: float | None = None


def load_model():
    global models, calibrators, feature_cols, metrics, active_version, metadata
    if has_current_model(MODELS_DIR):
        try:
            info = load_current_model(MODELS_DIR)
            models = info["models"]
            calibrators = info.get("calibrators", {})
            feature_cols = info["feature_cols"]
            metrics = info["metrics"]
            active_version = info["version"]
            metadata = info.get("metadata", {})
            print(f"[MastiSense] Active production model loaded: version {active_version}")
        except Exception as e:
            models = {}; calibrators = {}; feature_cols = []; metrics = {}
            active_version = None; metadata = {}
            print(f"[MastiSense] Error loading models/current: {e}")
    else:
        models = {}; calibrators = {}; feature_cols = []; metrics = {}
        active_version = None; metadata = {}
        print("[MastiSense] Notice: No validated production model in models/current/ — predictions disabled.")


def cow(cow_id):
    c = connect()
    r = c.execute("SELECT * FROM cows WHERE cow_id=?", (cow_id,)).fetchone()
    c.close()
    return dict(r) if r else None


def raw(cow_id):
    c = connect()
    rows = c.execute(
        "SELECT * FROM readings WHERE cow_id=? ORDER BY timestamp", (cow_id,)
    ).fetchall()
    c.close()
    return pd.DataFrame([dict(x) for x in rows])


def tier(p):
    if p < TIER_THRESHOLDS["no_risk"]:
        return "No Risk"
    elif p < TIER_THRESHOLDS["low_risk"]:
        return "Low Risk"
    elif p < TIER_THRESHOLDS["moderate_risk"]:
        return "Moderate Risk"
    return "High Risk"


def build_features(cow_id):
    info = cow(cow_id)
    if not info:
        raise HTTPException(404, "Cow not registered")
    r = raw(cow_id)
    if r.empty:
        raise HTTPException(404, "No readings for cow")
    d = aggregate_daily(r)
    for k in [
        "age_years", "parity", "vaccination_status",
        "prior_mastitis_flag", "breed", "calving_date", "herd_id",
    ]:
        d[k] = info.get(k)
    f = engineer(d)
    missing = [c for c in feature_cols if c not in f.columns]
    if missing:
        raise HTTPException(
            500,
            f"Model/feature mismatch: retrain the models (missing columns: {missing[:5]}"
            + (", ..." if len(missing) > 5 else "") + ")",
        )
    return info, d, f


def prediction_row(model_key, f, row_index=-1):
    model = models[model_key]
    x = f[feature_cols].iloc[[row_index]]
    raw_p = float(model.predict_proba(x)[:, 1][0])
    cal = calibrators.get(model_key)
    if cal is not None:
        p = float(apply_calibration([raw_p], cal)[0])
        p = max(0.0, min(1.0, p))
    else:
        p = raw_p
    return p, x, raw_p


def predict(cow_id):
    if not models:
        load_model()
    if not models:
        raise HTTPException(
            503,
            detail="No validated production model is currently approved for serving. "
                   "Trained candidates exist under models/ for audit but failed promotion gates."
        )

    info, d, f = build_features(cow_id)
    p7, x7, raw_p7 = prediction_row("7d", f)
    p14, x14, raw_p14 = prediction_row("14d", f)
    days = int(len(d))

    # Data sufficiency warning (§6)
    data_warning = (
        f"Limited history ({days} days) — early warning reliability is reduced; "
        "accumulating >= 7 daily readings improves forecast precision."
        if days < 7 else None
    )

    # Check SCC staleness (§5)
    c = connect()
    scc_staleness_warn = check_scc_staleness(cow_id, c)
    c.close()

    resp = {
        # Core backward-compatible fields
        "cow_id": cow_id,
        "date": str(f.timestamp.iloc[-1]),
        "data_days": days,
        "risk_score_7d": round(p7, 4),
        "risk_percent_7d": round(p7 * 100, 1),
        "risk_tier_7d": tier(p7),
        "risk_score_14d": round(p14, 4),
        "risk_percent_14d": round(p14 * 100, 1),
        "risk_tier_14d": tier(p14),
        "forecast_horizon_days": [7, 14],
        "top_driver_features": top_drivers(x7, models["7d"]),
        "top_driver_features_14d": top_drivers(x14, models["14d"]),
        "recommendations": recommendations(x7.iloc[0].to_dict()),
        "note": (
            "Risk is calculated using all daily information accumulated for this cow "
            "up to the latest sample. This is prototype decision support, not a clinical diagnosis."
        ),
        # Provenance metadata (§13)
        "model_version": active_version,
        "training_data_type": DATA_TYPE,
        "feature_pipeline_version": FEATURE_PIPELINE_VERSION,
        "calibration_method": "sigmoid",
        "raw_risk_score_7d": round(raw_p7, 4),
        "raw_risk_score_14d": round(raw_p14, 4),
        "baseline_mode": not USE_REAL_FARM_FEATURES,
        "prediction_timestamp": datetime.now(timezone.utc).isoformat(),
        # Data sufficiency & staleness (§6, §5)
        "data_sufficiency_warning": data_warning,
        "scc_staleness_warning": scc_staleness_warn,
    }
    return resp


def risk_history(cow_id):
    if not models:
        load_model()
    if not models:
        return []

    _, d, f = build_features(cow_id)
    rows = []
    for i in range(len(f)):
        p7, _, raw_p7 = prediction_row("7d", f, i)
        p14, _, raw_p14 = prediction_row("14d", f, i)
        rows.append({
            "date": str(f.timestamp.iloc[i]),
            "data_days": i + 1,
            "risk_percent_7d": round(p7 * 100, 1),
            "risk_tier_7d": tier(p7),
            "risk_percent_14d": round(p14 * 100, 1),
            "risk_tier_14d": tier(p14),
            "raw_risk_score_7d": round(raw_p7, 4),
            "raw_risk_score_14d": round(raw_p14, 4),
        })
    return rows


def maybe_alert(res):
    """Create one alert per cow/day when either forecast horizon is high risk."""
    if not res or (res.get("risk_tier_7d") != "High Risk" and res.get("risk_tier_14d") != "High Risk"):
        return False

    high7 = res["risk_tier_7d"] == "High Risk"
    high14 = res["risk_tier_14d"] == "High Risk"
    day = res["date"][:10]
    if high7 and high14:
        message = (
            f"High mastitis risk. 7-day: {res['risk_percent_7d']:.1f}%, "
            f"14-day: {res['risk_percent_14d']:.1f}%. Re-check the cow and follow veterinary protocol."
        )
    elif high7:
        message = (
            f"High 7-day mastitis risk ({res['risk_percent_7d']:.1f}%). "
            "Re-check the cow and follow veterinary protocol."
        )
    else:
        message = (
            f"High 14-day mastitis risk ({res['risk_percent_14d']:.1f}%). "
            "Increase monitoring and follow veterinary protocol."
        )

    # Avoid duplicate open alerts for the same cow and forecast day.
    c = connect()
    exists = c.execute(
        "SELECT 1 FROM alerts WHERE cow_id=? AND substr(timestamp,1,10)=? AND message LIKE 'High%mastitis risk%' LIMIT 1",
        (res["cow_id"], day),
    ).fetchone()
    if not exists:
        score = max(res["risk_score_7d"], res["risk_score_14d"])
        m_version = res.get("model_version", active_version or "unvalidated")
        c.execute(
            "INSERT INTO alerts(cow_id,timestamp,risk_score,message,model_version) VALUES(?,?,?,?,?)",
            (res["cow_id"], datetime.now(timezone.utc).isoformat(), score, message, m_version),
        )
        c.commit()
        created = True
    else:
        created = False
    c.close()
    return created


@app.on_event("startup")
def startup():
    init_db()
    load_model()


@app.get("/")
def root():
    cands = [v["version"] for v in list_versions()]
    return {
        "message": "MastiSense Daily 7/14-Day Mastitis Risk Forecasting API",
        "docs": "/docs",
        "model_status": "active" if active_version else "no_active_model",
        "model_version": active_version,
        "candidate_versions": cands,
        "note": (
            f"Production model {active_version} active."
            if active_version else
            "No validated production model is currently approved for serving. "
            "Trained candidates exist in models/ for audit."
        ),
        "feature_pipeline_version": FEATURE_PIPELINE_VERSION,
        "data_type": DATA_TYPE,
    }


@app.get("/metrics")
def get_metrics():
    if metrics:
        return metrics
    # Return candidate summaries for audit when no production model is active
    return {
        "status": "no_active_production_model",
        "note": "No model candidate has passed the promotion quality bar for production serving.",
        "candidate_summaries": list_versions(),
    }


@app.get("/drift/summary")
def get_drift_summary(days: int = 30):
    c = connect()
    report = summarize_drift(c, recent_days=days)
    c.close()
    return report


@app.post("/ingest")
def ingest(r: Reading):
    errors = validate_reading(r)
    if errors:
        raise HTTPException(422, errors)
    if not cow(r.cow_id):
        raise HTTPException(404, "Register cow first with POST /cows")
    ts = r.timestamp or datetime.now(timezone.utc).isoformat()
    try:
        datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(422, "timestamp must be ISO 8601")

    # Data-quality checks (§16)
    quality_warnings = check_reading_quality(r)
    quality_warnings.extend(check_timestamp_sanity(ts))

    c = connect()
    jump_warnings = check_abnormal_jump(r.cow_id, r, c)
    quality_warnings.extend(jump_warnings)

    # Derive heat index if farm_temperature_c and farm_humidity provided (DHT22)
    heat_index = r.environment_heat_index
    if heat_index is None and r.farm_temperature_c is not None and r.farm_humidity is not None:
        heat_index = round(r.farm_temperature_c + 0.36 * r.farm_humidity - 10.0, 1)

    c.execute("""INSERT INTO readings(
                 cow_id,timestamp,milk_yield_l,milk_conductivity,milk_temp_c,scc_value,
                 activity_score,rumination_min,environment_heat_index,hygiene_score,
                 feed_score,milking_hygiene_score,source,
                 farm_temperature_c,farm_humidity,milk_pH,body_temperature,udder_surface_temperature)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (r.cow_id, ts, r.milk_yield_l, r.milk_conductivity, r.milk_temp_c, r.scc_value,
               r.activity_score if r.activity_score is not None else FIXED_GOOD_VALUES["activity_score"],
               r.rumination_min if r.rumination_min is not None else FIXED_GOOD_VALUES["rumination_min"],
               heat_index if heat_index is not None else FIXED_GOOD_VALUES["environment_heat_index"],
               r.hygiene_score if r.hygiene_score is not None else FIXED_GOOD_VALUES["hygiene_score"],
               r.feed_score if r.feed_score is not None else FIXED_GOOD_VALUES["feed_score"],
               r.milking_hygiene_score if r.milking_hygiene_score is not None else FIXED_GOOD_VALUES["milking_hygiene_score"],
               r.source,
               r.farm_temperature_c, r.farm_humidity, r.milk_pH, r.body_temperature, r.udder_surface_temperature))
    c.commit()
    c.close()

    # If an approved model is active, compute risk and evaluate alerts;
    # otherwise, record data permanently but report that no model is approved.
    if not models:
        try:
            load_model()
        except Exception:
            pass

    if models:
        result = predict(r.cow_id)
        maybe_alert(result)
    else:
        result = None

    return {
        "stored": True,
        "cow_id": r.cow_id,
        "timestamp": ts,
        "risk": result,
        "model_status": "active" if models else "no_active_model",
        "quality_warnings": quality_warnings if quality_warnings else None,
        "note": (
            "Reading recorded and risk predicted."
            if models else
            "Reading recorded permanently. Risk prediction skipped because no validated "
            "production model is currently approved for serving."
        ),
    }


@app.get("/cows/{cow_id}/risk")
def cow_risk(cow_id):
    res = predict(cow_id)
    maybe_alert(res)
    return res


@app.get("/cows/{cow_id}/risk-history")
def cow_risk_history(cow_id):
    return risk_history(cow_id)


@app.get("/cows/{cow_id}/history")
def history(cow_id):
    r = raw(cow_id)
    if r.empty:
        raise HTTPException(404, "No readings")
    return r.astype(object).where(pd.notna(r), None).to_dict(orient="records")


@app.get("/herd/risk")
def herd_risk():
    if not models:
        try:
            load_model()
        except Exception:
            pass
    if not models:
        return []

    c = connect()
    ids = [x[0] for x in c.execute("SELECT cow_id FROM cows").fetchall()]
    c.close()
    out = []
    for cid in ids:
        try:
            out.append(predict(cid))
        except HTTPException:
            continue
        except Exception as e:
            print(f"[herd/risk] prediction failed for {cid}: {e!r}")
    return sorted(out, key=lambda x: x.get("risk_score_7d", 0), reverse=True)


@app.get("/alerts")
def alerts(status: str | None = None):
    c = connect()
    if status:
        rows = c.execute(
            "SELECT * FROM alerts WHERE status=? ORDER BY id DESC LIMIT 50", (status,)
        ).fetchall()
    else:
        rows = c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 50").fetchall()
    c.close()
    return [dict(x) for x in rows]


@app.post("/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int, body: dict | None = None):
    note = (body or {}).get("note", "")
    c = connect()
    row = c.execute("SELECT id FROM alerts WHERE id=?", (alert_id,)).fetchone()
    if not row:
        c.close()
        raise HTTPException(404, "Alert not found")
    c.execute(
        "UPDATE alerts SET status='resolved', resolved_at=?, resolved_note=? WHERE id=?",
        (datetime.now(timezone.utc).isoformat(), note, alert_id),
    )
    c.commit()
    c.close()
    return {"status": "resolved", "alert_id": alert_id}


@app.post("/alerts/check")
def check_alerts():
    """Evaluate all cows and persist alerts for high 7-day or 14-day risk."""
    if not models:
        try:
            load_model()
        except Exception:
            pass
    if not models:
        return {
            "status": "skipped",
            "high_risk_count": 0,
            "high_risk_cows": [],
            "new_alerts_created": 0,
            "note": "Alert check skipped: no validated production model approved for serving.",
        }

    h = herd_risk()
    high = [x for x in h if x.get("risk_tier_7d") == "High Risk" or x.get("risk_tier_14d") == "High Risk"]
    created = sum(1 for x in high if maybe_alert(x))
    return {
        "status": "evaluated",
        "high_risk_count": len(high),
        "high_risk_cows": high,
        "new_alerts_created": created,
    }


@app.post("/feedback")
def feedback(body: dict):
    if "cow_id" not in body:
        raise HTTPException(400, "cow_id required")
    c = connect()
    c.execute(
        "INSERT INTO feedback(cow_id,event_date,confirmed_mastitis,notes) VALUES(?,?,?,?)",
        (body["cow_id"], body.get("event_date"), body.get("confirmed_mastitis"), body.get("notes", "")),
    )
    c.commit()
    c.close()
    return {"stored": True, "message": "Outcome stored for future model retraining."}
