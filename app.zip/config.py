"""MastiSense — Centralized configuration.

All configurable values in one place.  Existing modules continue to
re-export the values their callers already import (backward-compatible);
new modules import from here.
"""
from pathlib import Path
import os

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATABASE_PATH = Path(os.getenv("MASTISENSE_DB", str(ROOT / "mastitis.db")))
MODELS_DIR = Path(os.getenv("MASTISENSE_MODELS", str(ROOT / "models")))

# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
API_HOST = os.getenv("MASTISENSE_HOST", "127.0.0.1")
API_PORT = int(os.getenv("MASTISENSE_PORT", "8000"))
CORS_ORIGINS = os.getenv("MASTISENSE_CORS", "*").split(",")

# ---------------------------------------------------------------------------
# Feature pipeline
# ---------------------------------------------------------------------------
FEATURE_PIPELINE_VERSION = "4.1"

# Core signals — always present in readings table.
CORE_SIGNALS = [
    "milk_yield_l",
    "milk_conductivity",
    "milk_temp_c",
    "scc_value",
    "activity_score",
    "rumination_min",
    "environment_heat_index",
    "hygiene_score",
    "feed_score",
    "milking_hygiene_score",
]

# Optional/extensible signals — included when the column exists in data.
OPTIONAL_SIGNALS = [
    "milk_pH",
    "body_temperature",
    "udder_surface_temperature",
    "farm_temperature_c",
    "farm_humidity",
]

# Fixed healthy baseline values for prototype mode (§10).
# Used when real farm/behaviour inputs are not yet physically collected.
FIXED_GOOD_VALUES = {
    "activity_score": 0.90,
    "rumination_min": 520.0,
    "environment_heat_index": 70.0,
    "hygiene_score": 0.90,
    "feed_score": 0.90,
    "milking_hygiene_score": 0.95,
}

SCC_DEFAULT = 180_000.0
MAX_SENSOR_FFILL_DAYS = 2

# ---------------------------------------------------------------------------
# SCC reference thresholds
# These are prototype references, NOT universal veterinary diagnostic cutoffs.
# ---------------------------------------------------------------------------
SCC_SUBCLINICAL_THRESHOLD = 200_000   # cells/mL
SCC_HIGH_THRESHOLD = 400_000
SCC_STALENESS_DAYS = 7  # days before carried-forward SCC is flagged stale

# ---------------------------------------------------------------------------
# Risk tier thresholds (application/UI thresholds, not diagnostic cutoffs)
# ---------------------------------------------------------------------------
TIER_THRESHOLDS = {"no_risk": 0.25, "low_risk": 0.50, "moderate_risk": 0.75}

# ---------------------------------------------------------------------------
# Sensor-range validation limits
# ---------------------------------------------------------------------------
SENSOR_LIMITS = {
    "milk_yield_l": (0, 100),
    "milk_conductivity": (0.01, 30),
    "milk_temp_c": (30, 45),
    "scc_value": (0, 20_000_000),
    "farm_temperature_c": (-10, 55),
    "farm_humidity": (0, 100),
    "milk_pH": (4.0, 9.0),
    "body_temperature": (35, 43),
    "udder_surface_temperature": (25, 45),
}

# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------
TRAINING_SEED = 2026
TARGET_RECALL_7D = 0.80
TARGET_RECALL_14D = 0.60
TARGET_RECALL = TARGET_RECALL_7D  # backward-compatible default
TARGET_RECALLS = {"7d": TARGET_RECALL_7D, "14d": TARGET_RECALL_14D}
MIN_PROMOTION_RECALL = {"7d": 0.70, "14d": 0.50}
USE_REAL_FARM_FEATURES = False

# ---------------------------------------------------------------------------
# Data type label — attached to all metrics/predictions for transparency
# ---------------------------------------------------------------------------
DATA_TYPE = "synthetic"
