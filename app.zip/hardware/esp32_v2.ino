#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

const char* WIFI_SSID="YOUR_HOTSPOT";
const char* WIFI_PASSWORD="YOUR_PASSWORD";
const char* SERVER="http://YOUR_LAPTOP_IP:8000/ingest";

// Set uniquely per device/collar so multiple boards can feed the same herd
// dashboard without editing any server-side code.
const char* COW_ID="cow_001";

#define ONE_WIRE_BUS 4
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// One daily sample is the intended prototype workflow.
// For a fast demo, temporarily change this to 10000UL (10 seconds).
const unsigned long SAMPLE_INTERVAL_MS = 86400000UL;
unsigned long lastSample = 0;

// Field connectivity (GSM/Wi-Fi hotspot) can drop mid-day. If a send fails,
// retry sooner instead of silently losing that day's reading until the next
// full interval.
const unsigned long RETRY_INTERVAL_MS = 5UL * 60UL * 1000UL; // 5 minutes
bool lastSendOk = true;

bool ensureWifi(){
  if(WiFi.status()==WL_CONNECTED) return true;
  Serial.println("WiFi not connected, attempting reconnect...");
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while(WiFi.status()!=WL_CONNECTED && millis()-start < 15000UL){
    delay(500); Serial.print(".");
  }
  Serial.println();
  return WiFi.status()==WL_CONNECTED;
}

bool sendSample(){
  sensors.requestTemperatures();
  float tempC=sensors.getTempCByIndex(0);

  // Replace these two values with calibrated sensor readings.
  float conductivity=4.8;
  float milkYieldL=14.0;

  String body=String("{\"cow_id\":\"")+COW_ID+"\",\"milk_yield_l\":"+String(milkYieldL,2)+
    ",\"milk_conductivity\":"+String(conductivity,2)+
    ",\"milk_temp_c\":"+String(tempC,2)+",\"source\":\"esp32\"}";

  if(!ensureWifi()){
    Serial.println("No WiFi -- reading not sent, will retry shortly.");
    return false;
  }

  HTTPClient http;
  http.begin(SERVER);
  http.addHeader("Content-Type","application/json");
  int code=http.POST(body);
  Serial.println(code);
  Serial.println(http.getString());
  http.end();
  return code >= 200 && code < 300;
}

void setup(){
  Serial.begin(115200);
  sensors.begin();
  ensureWifi();
  lastSendOk = sendSample();
  lastSample=millis();
}

void loop(){
  unsigned long interval = lastSendOk ? SAMPLE_INTERVAL_MS : RETRY_INTERVAL_MS;
  if(millis()-lastSample >= interval){
    lastSendOk = sendSample();
    lastSample=millis();
  }
  delay(1000);
}
